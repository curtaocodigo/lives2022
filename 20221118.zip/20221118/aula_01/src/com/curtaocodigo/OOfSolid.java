package com.curtaocodigo;

public class OOfSolid {

    class UserWithoutSolid{
        private String name;
        private String cnpj;
    }

    class User{
        private String name;
    }

    class UserPJ extends User{
        private String cnpj;
    }

}
