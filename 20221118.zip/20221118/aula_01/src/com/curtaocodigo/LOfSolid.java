package com.curtaocodigo;

public class LOfSolid {

    interface IUserWithoutSolid{
        String getName();
        String getNomeFantasia();
    }

    interface IUser{
        String getName();
    }

    interface IUserPJ extends IUser{
        String getNomeFantasia();
    }

    class UserPJWithoutSolid implements IUserPJ {
        private String cnpj;
        private String nomeFantasia;
        private String razaoSocial;

        public String getName(){
            return razaoSocial;
        }

        @Override
        public String getNomeFantasia() {
            return nomeFantasia;
        }
    }

    class UserPFWithoutSolid implements IUser {
        private String cnpj;
        private String nome;

        @Override
        public String getName() {
            return nome;
        }
    }
}
