package com.curtaocodigo;

public class DOfSolid {

    class SamsungUprightFreezerWithoutSolid{
        void freeze(String thing){
            System.out.println("Your ".concat(thing).concat(" is frozen"));
        }
    }

    void freezeMyBottleOfWaterWithoutSolid(){
        SamsungUprightFreezerWithoutSolid freezerNoSolid = new SamsungUprightFreezerWithoutSolid();
        String thing = "bottle of water";
        freezerNoSolid.freeze(thing);
    }

    interface Freezer{
        void freeze(String thing);
    }

    class SamsungUprightFreezer implements Freezer{
        public void freeze(String thing){
            System.out.println("Your ".concat(thing).concat(" is frozen"));
        }
    }

    class PanasonicUprightFreezer implements Freezer{
        public void freeze(String thing){
            System.out.println("Your ".concat(thing).concat(" is frozen by Panasonic"));
        }
    }

    void freezeMyBottleOfWater(Freezer freeze){
        String thing = "bottle of water";
        freeze.freeze(thing);
    }

    void freezeThing(){
        Freezer freezeS = new SamsungUprightFreezer();
        freezeMyBottleOfWater(freezeS);
        Freezer freezeP = new PanasonicUprightFreezer();
        freezeMyBottleOfWater(freezeP);
    }
}
