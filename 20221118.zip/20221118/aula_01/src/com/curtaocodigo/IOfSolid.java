package com.curtaocodigo;

public class IOfSolid {
    interface ICarWithoutSolid{
        public void accelerate();
        public void breaking();
        public void printSpeedSpeedometer();
    }
    interface ICarCommands{
        public void accelerate();
        public void breaking();
    }
    interface ICarPrintInstruments{
        public void printSpeedSpeedometer();
    }
}
