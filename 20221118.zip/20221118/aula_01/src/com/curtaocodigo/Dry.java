package com.curtaocodigo;

import java.util.Arrays;

public class Dry {
    class SomaDry {
        public double somaNumero1Numero2(double num1, double num2){
            return num1 + num2;
        }
        public double somaNumero1Numero2Numero3(double num1, double num2, double num3){
            return num1 + num2 + num3;
        }
        public double somaNumeros(double ... nums){
            return Arrays.stream(nums).sum();
        }
    }
    public void somaDry(){
        double num1 = 10.50;
        double num2 = 20.50;
        double num3 = 30;

        SomaDry somaDry = new SomaDry();
        double total  = somaDry.somaNumero1Numero2(num1,num2);
        System.out.println("soma 1 e 2 "+total);
        double total2  = somaDry.somaNumero1Numero2Numero3(num1,num2,num3);
        System.out.println("soma 1, 2 e 3 "+total2);

        double total3  = somaDry.somaNumeros(num1,num2);
        System.out.println("soma numeros 1,2 "+total3);
        double total4  = somaDry.somaNumeros(num1,num2,num3);
        System.out.println("soma numeros 1,2,3 "+total4);
    }
    
    public static void main(String[] args) {
        new Dry().somaDry();
    }
}
