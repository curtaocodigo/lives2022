package com.curtaocodigo;

public class SOfSolid {
    class UserWithoutSolid{
        String firstName;
        String lastName;

        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        void printName(){
            System.out.println(firstName + lastName);
        }
    }
    class User{
        String firstName;
        String lastName;
    }
    class UserPrinter{
        User user;
        UserPrinter(User user){
            this.user = user;
        }
        void printName() {
            System.out.println(user.firstName + user.lastName);
        }
    }
}
