from .models import Perfil
from rest_framework import viewsets, permissions
from .serializers import PerfilSerializer


class PerfilViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = Perfil.objects.all().order_by('-id')
    serializer_class = PerfilSerializer
    permission_classes = [permissions.IsAuthenticated]