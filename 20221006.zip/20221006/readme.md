# pythoncurtaone
Repository for python curta one - Aula Python

# run commands below to create a new venv, install dependencies and migrate correctly
python -m venv venv
.\venv\Scripts\activate
pip install django 
pip install djangorestframework
pip install markdown
pip install django-filter
pip install pygments

# first creation setup - do not execute it if perfis is created 
py manage.py startapp perfis

# after first creation setup
py manage.py makemigrations perfis
py manage.py migrate

# first creation setup - do not execute it if admin is created 
python manage.py createsuperuser --email admin@example.com --username admin

# run server
py manage.py runserver

# documentação de open api
pip install drf-spectacular